<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="{{ asset('style-menu user.css')}}">
    <link rel="stylesheet" href="{{ asset('css/catalog.css')}}">
    
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Poppins&display=swap" rel="stylesheet">
</head>
<body>
    <div class="navigation flex-column">
        <div class="logo flex-column">
            <img src="{{ asset('Asset/letter_p_PNG119 1.svg')}}" alt="">
            <h1>harmacy</h1>
        </div>
        <div class="menu flex-column">
            <img src="{{ asset('Asset/gg_menu-grid-o.png')}}" alt="">
            <img src="{{ asset('Asset/clarity_notification-outline-badged.png')}}" alt="">
            <img src="{{ asset('Asset/emojione_shopping-cart (1).png')}}" alt="">
        </div>
    </div>
    <div class="container">
        <div class="navbar-samping flex-column">
            <div class="menu-samping flex-column">
                <div class="account flex-column">
                    <div class="navbar-icon">
                        <img src="{{ asset('Asset/ic_round-account-circle.png')}}" alt="">
                    </div>
                    <h3>User</h3>
                </div>
                <h3>
                    <a href="user - menu product.html" class="active">Product</a>
                </h3>
                <h3>
                    <a href="user - menu form order.html">Order</a>
                </h3>
                <h3>
                    <a href="user - menu payment.html">Payment</a>
                </h3>
                <h3>
                    <a href="user - menu delivery.html">Delivery</a>
                </h3>
            </div>
            <div class="log-out flex-column">
                <h3>
                    <a href="{{ route('logout')}}">Log-Out</a>
                </h3>
                <img src="{{ asset('Asset/feather_log-out.svg')}}" alt="">
            </div>
        </div>
        <form class="container-child">
            <div class="title">
                <h2>Katalog Product</h2>
            </div>
            <div class="flex-row list-product">
                <div class="flex-column product">
                    <div class="flex-row product-photo">
                        <img src="{{ asset('img/photo/product-1.png')}}" alt="">
                    </div>
                    <div class="flex-column poppins product-description">
                        <h2>METFORMIN 500MG</h2>
                        <p>Per Box (100 Tablet)</p>
                        <span>Rp 19.000</span>
                    </div>
                    <button onclick="location.href='user - menu form order.html'" type="button" class="poppins">TAMBAH</button>
                </div>
                <div class="flex-column product">
                    <div class="flex-row product-photo">
                        <img src="{{ asset('img/photo/product-2.png')}}" alt="">
                    </div>
                    <div class="flex-column poppins product-description">
                        <h2>CANDESARTAN 32MG</h2>
                        <p>Per Box (30 Tablet)</p>
                        <span>Rp 25.200</span>
                    </div>
                    <button onclick="location.href='user - menu form order.html'" type="button" class="poppins">TAMBAH</button>
                </div>
                <!-- <div class="flex-column product">
                    <div class="flex-row product-photo">
                        <img src="img/photo/product-3.png" alt="">
                    </div>
                    <div class="flex-column poppins product-description">
                        <h2>ATORVASTATIN 20MG</h2>
                        <p>Per Box (30 Tablet)</p>
                        <span>Rp 96.300</span>
                    </div>
                    <button onclick="location.href='user - menu form order.html'" type="button" class="poppins">TAMBAH</button>
                </div> -->
                <div class="flex-column product">
                    <div class="flex-row product-photo">
                        <img src="{{ asset('img/photo/product-4.png')}}" alt="">
                    </div>
                    <div class="flex-column poppins product-description">
                        <h2>SIMVASTATIN 20MG</h2>
                        <p>Per 3 Strip</p>
                        <span>Rp 16.800</span>
                    </div>
                    <button onclick="location.href='user - menu form order.html'" type="button" class="poppins">TAMBAH</button>
                </div>
                <div class="flex-column product">
                    <div class="flex-row product-photo">
                        <img src="{{ asset('img/photo/product-5.png')}}" alt="">
                    </div>
                    <div class="flex-column poppins product-description">
                        <h2>ASPILETS 20 TABLET</h2>
                        <p>Per 3 Strip</p>
                        <span>Rp 28.200</span>
                    </div>
                    <button onclick="location.href='user - menu form order.html'" type="button" class="poppins">TAMBAH</button>
                </div>
            </div>

        </form>
        <!-- <div class="container-img">
            <img src="Asset/Group 2.png" alt="">
        </div> -->
        
    </div>
</body>
</html>